# *******************************************************
# Nom .......... : cacher.py
# Rôle ......... : Cacher un message dans une image
# Auteur ....... : Maryam Joyez
# Version ...... : V0.1
# Compilation .. : Aucune compilation nécessaire
# Usage .........: python cacher.py
# *******************************************************

# -------------------------------------------------------
# Fonction de dissimulation d'un message dans une image
# -------------------------------------------------------

from PIL import Image
import codecs

# Chargement de l'image en mode RGB pour avoir 3 valeurs par pixels
png = Image.open("mnemosyne.png").convert("RGB") 
larg, haut = png.size


# Préparation du message à encoder avec ROT13 pour le rendre illisible
message = "Est ce qu'on peut avoir 20 svp ? :)"
encode = codecs.decode(message, "rot_13")

# Transformation du message en 8 bits par caractères
texte_bin = ""
for car in encode:
    texte_bin += str('{0:08b}'.format(ord(car)))
texte_bin += "111"

longueur = len(texte_bin)
index = 0
i = 0

# Dans le format png, un pixel peut être composé de 3 ou 4 valeurs.
nb_val = 3   # mettre eventuellement 4

# Insertion et lecture directe du pixel
# On parcourt le message par pixel pour y insérer le message chiffré
for k in range(longueur//nb_val):
    col = index % larg
    row = index // larg

    # Utilisation de getpixel pour récupérer la valeurs des 3 couleurs d'un pixel
    v = list(png.getpixel((col, row)))

    for j in range(nb_val):
        # Si la valeur du bit du texte ne correspond pas à la parite de l'image alors la modifier de 1
        if (v[j]%2==0 and int(texte_bin[i])==1) or (v[j]%2==1 and int(texte_bin[i])==0) :
            if v[j]>=255:
                v[j] -= 1
            else :
                v[j] += 1
        i += 1

    # Réinsertion des modifications dans l'image
    png.putpixel((col,row), tuple(v))

# Sauvegarde du résultat
png.save('stegano.png')

print("Nouvelle image : stegano.png a été enregistrée")