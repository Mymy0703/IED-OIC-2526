# *******************************************************
# Nom .......... : test.py
# Rôle ......... : Ecrire un message dans une image
# Auteur ....... : Maryam Joyez
# Version ...... : V0.1
# Compilation .. : Aucune compilation nécessaire
# Usage .........: python test.py
# *******************************************************

# -------------------------------------------------------
# Fonction de dissimulation d'un message dans une image
# -------------------------------------------------------
from PIL import Image
import codecs

message = "Est-ce qu'on peux avoir un 20/20 svp"
encode = codecs.decode(message, "rot_13")

png = Image.open("mnemosyne.png")   # le nom du fichier de l'image
pixels = png.getdata()
larg, haut = png.size

texte = "Est-ce qu'on peux avoir un 20/20 svp" 
encode= codecs.decode(message, "rot_13")

texte_bin = ""
for car in encode:
    texte_bin += str('{0:08b}'.format(ord(car)))
texte_bin += "111"  # pour etre sur que tut est bien chiffre

longueur = len(texte_bin)
index = 0
i = 0


nb_val = 3   # mettre eventuellement 4

for k in range(longueur//nb_val):
    if nb_val == 3:
        v=[pixels[k][0],pixels[k][1],pixels[k][2]]
    else:
        v=[pixels[k][0],pixels[k][1],pixels[k][2],pixels[k][3]]
    for j in range(nb_val):
        # Si la valeur du bit du texte ne correspond pas a la parite de l'image alors la modifer de 1
        if (v[j]%2==0 and int(texte_bin[i])==1) or (v[j]%2==1 and int(texte_bin[i])==0) :
            if v[j]>=255:
                v[j] -= 1
            else :
                v[j] += 1
        i += 1
    col = index % larg
    row = index // larg
    png.putpixel((col,row), tuple(v))
    index += 1

png.save('stegano.png')

print("Nouvelle image : stegano.png")